#include <atomic>
#include <iostream>
#include <threads.h>
#include "rwlock.h"
#include "mcsqueue.h"
#include "node.h"
#include "SNZI.h"
#include "librace.h"

int var = 0;

rwlock* lock;
rwlock::rwlock(int thrd_num)
{
  readFlag.store(true,memory_order_relaxed);//the writer queue should be empty in the first place
  reader_tree=new SNZI(thrd_num);
  mcsqueue=new writer_queue(thrd_num,this);
}
rwlock::~rwlock()
{
  delete mcsqueue;
  delete reader_tree;
}
void rwlock::reader_lock(int thread_id)
{
  int mystamp = mcsqueue->get_wait_timer();
  int temp1;
  int temp2;
 // printf("Im thread %d, my timestamp is: %d\n",thread_id,mystamp);
  do
  {
     temp2 =mcsqueue->get_wait_timer();
     temp1 = mcsqueue->get_cur_timer();
     if(mystamp > temp1 && mystamp > temp2 && temp2 > temp1)
     break;
  }
  while((mystamp > temp1) || (mystamp+30000 < temp1));
  //add timestamp compare here
  //reader_tree->addReader(thread_id);
  reader_tree->arrive(thread_id);
  while (!readFlag.load(memory_order_seq_cst));
}
void rwlock::reader_unlock(int thread_id)
{
  //reader_tree->readerExit(thread_id);
  reader_tree->depart(thread_id);
}
void rwlock::writer_lock(int thread_id)
{
  mcsqueue->writer_lock(thread_id);
}
void rwlock::writer_unlock(int thread_id)
{
  mcsqueue->writer_unlock(thread_id);
}

void rwlock::set_read_flag(bool flag)
{
  readFlag.store(flag,memory_order_seq_cst);
}

uint32_t rwlock::get_I()
{
  return reader_tree->getI();
}






void unit_test_routine1(void* input)
{
   
   int thread_id = *(int*)input;
   if(thread_id > 8)
   {
     lock->writer_lock(thread_id);
     printf("writer thread with number %d hit critical section with read_flag:%d and %d!!\n",thread_id,lock->get_I(),lock->readFlag.load(memory_order_relaxed));
     store_32(&var,thread_id);
     lock->writer_unlock(thread_id);
   } 
   else if(!(thread_id % 4))
   {
     lock->writer_lock(thread_id);
     printf("writer thread with number %d hit critical section with read_flag:%d and %d!!\n",thread_id,lock->get_I(),lock->readFlag.load(memory_order_relaxed));
     store_32(&var,thread_id);
     lock->writer_unlock(thread_id);
   }
   else
   {
     lock->reader_lock(thread_id);
     printf("reader thread with number %d hit critical section with read_flag:%d and %d!!\n",thread_id,lock->get_I(),lock->readFlag.load(memory_order_relaxed));
     load_32(&var);
     lock->reader_unlock(thread_id);
   }

}


void unit_test_routine2(void* input)
{
   
   int thread_id = *(int*)input;
   if(!(thread_id % 4))
   {
     lock->writer_lock(thread_id);
     printf("writer thread with number %d hit critical section with read_flag:%d and %d!!\n",thread_id,lock->get_I(),lock->readFlag.load(memory_order_relaxed));
     store_32(&var,thread_id);
     lock->writer_unlock(thread_id);
   }
   else
   {
     lock->reader_lock(thread_id);
     printf("reader thread with number %d hit critical section with read_flag:%d and %d!!\n",thread_id,lock->get_I(),lock->readFlag.load(memory_order_relaxed));
     load_32(&var);
     lock->reader_unlock(thread_id);
   }

}

void unit_test_routine3(void* input)
{
   
   

}


int user_main(int argc, char *argv[])
{
  int trn = 14;
  lock = new rwlock(trn);
  thrd_t B[trn];
  int temp[trn];
//unit test 1
  for(int i = 0; i < trn; i++) 
  {	
    
    temp[i] = i; 
    thrd_create(&B[i],&unit_test_routine2,&temp[i]);
    
  }
  for(int i = 0; i < trn; i++)  thrd_join(B[i]);

  delete lock;

  return 0;
}




