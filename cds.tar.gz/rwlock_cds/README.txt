Team members:

Haozhe Jiang 68249954
Jinsheng Zhu 33882845







The outer directory is the version of program with a user_main in order to accommodate the testing with cdscheck, extract it under /benchmark/rwlock and run make to compile the file. An executable file has already been included. There is another tarball called main.tar.gz that include the version of program with main function which can run directly. Extract it in some directory and run "make" to compile it. The description of our data structure is in description.txt. mcsqueue.cc/mcsqueue.h implements the mcsqueue, the SNZIReaderCounter implement the SNZI tree, the main function and test cases is written in rwlock.cc. 
